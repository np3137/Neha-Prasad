from  shop.views.signup import SignupView
from  shop.views.login import LoginView